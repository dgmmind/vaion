<script>feather.replace();</script>   
</body>
</html>    