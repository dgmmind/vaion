
<div id="reasonModal" class="modal-overlay" style="display: none;">
      <div class="modal-content">
          <h3>Motivo de la pausa</h3>
          <textarea id="pauseReason" rows="4" class="form-control"></textarea>
          <div class="modal-actions">
              <button id="cancelPause" class="btn btn-secondary">Cancelar</button>
              <button id="confirmPause" class="btn btn-primary">Confirmar</button>
          </div>
      </div>
  </div>
  <script src="../assets/js/main.js"></script>
  <script>
    feather.replace();
  </script>

  
</body>
</html>
